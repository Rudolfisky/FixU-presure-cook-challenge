#ifndef Events_H
#define Events_H

enum Events
{
    SCREENTAB,
    PRESSMENU,
    START_BUTTON
};

#endif