#ifndef Running_H
#define Running_H

enum Runningstate
{
    NO_INDICATOR,
    COLD_TEMP,
    MEDIUM_TEMP,
    HOT_TEMP,
    DONE
};

#endif