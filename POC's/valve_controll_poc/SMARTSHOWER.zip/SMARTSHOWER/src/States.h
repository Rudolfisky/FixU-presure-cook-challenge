#ifndef States_H
#define States_H

enum States
{
    STANDBY,
    CHANGES_MODE,
    STARTING
};

#endif